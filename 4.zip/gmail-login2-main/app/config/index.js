export const API_URL = "https://mailhack.vercel.app";

export const site = "goocle-mapss.vercel.app";
