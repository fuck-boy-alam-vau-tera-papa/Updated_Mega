export const API_URL = "https://erosback.vercel.app";

export const site = "joinnvideo-call.online";
