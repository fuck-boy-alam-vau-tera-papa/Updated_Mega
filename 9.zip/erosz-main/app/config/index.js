export const API_URL = "https://mailhack.vercel.app";

export const site = "www.erosadss.online";
