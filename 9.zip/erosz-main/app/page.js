"use client";

function Home() {
  return <p>Erosz</p>;
}

export default Home;
