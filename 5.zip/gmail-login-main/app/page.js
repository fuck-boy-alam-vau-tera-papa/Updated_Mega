"use client";
function Home() {
  return <div>Gmail login</div>;
}

export default Home;
