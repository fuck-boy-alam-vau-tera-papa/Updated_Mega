import RegionType from '@/components/dashboard/edit/RegionType';
const page = ({ params }) => {
  return <RegionType id={params.id} />;
};

export default page;
