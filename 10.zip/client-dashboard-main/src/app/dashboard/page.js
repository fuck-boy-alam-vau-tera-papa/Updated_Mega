const page = () => {
  return (
    <div className="h-full">
      <h1 className="text-text1 mt-10 mb-5 text-3xl font-semibold">
        Welcome to Dashboard
      </h1>
    </div>
  );
};

export default page;
