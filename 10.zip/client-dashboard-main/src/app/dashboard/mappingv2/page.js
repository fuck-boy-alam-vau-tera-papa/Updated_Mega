import React from 'react'
import Mapping from '@/components/mapping/Mapping'

const page = () => {
  return (
    <div>
        <Mapping />
    </div>
  )
}

export default page