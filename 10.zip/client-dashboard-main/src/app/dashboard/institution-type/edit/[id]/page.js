import INTtype from '@/components/dashboard/edit/INTtype';
const page = ({ params }) => {
  return <INTtype id={params.id} />;
};

export default page;
