const Footer = () => {
  return (
    <div className="bg-surface1 text-text1 text-center py-4">
      &copy; 2024 Kajal Brothers Ltd. All Rights Reserved.
    </div>
  );
};

export default Footer;
