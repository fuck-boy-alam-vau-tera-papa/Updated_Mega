/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['kblsf.site'],
  },
};

export default nextConfig;
