"use client";

export default function Home() {
  return <div className="">Megapersonalls</div>;
}
