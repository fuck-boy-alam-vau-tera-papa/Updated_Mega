function NotFoundPage() {
  return (
    <div className="mt-[300px] flex justify-center items-center">
      <p className="text-3xl font-semibold text-slate-600">Page Not Found</p>
    </div>
  );
}

export default NotFoundPage;
