export const posterLinksColumn = [
  {
    Header: "Website",
    accessor: "site",
  },
];
