export const linkColumn = [
  {
    Header: "Website",
    accessor: "site",
  },
  // {
  //   Header: "Status",
  //   accessor: "status",
  //   Cell: ({ value }) => (
  //     <div className="text-center">
  //       <span
  //         className={`px-3 py-1 rounded-full text-white ${
  //           value === "Active" ? "bg-blue-600" : "bg-red-600"
  //         }`}
  //       >
  //         {value}
  //       </span>
  //     </div>
  //   ),
  // },
];
