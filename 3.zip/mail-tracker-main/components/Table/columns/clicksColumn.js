export const clicksColumn = [
  {
    Header: "website",
    accessor: "site",
    width: 400,
  },
  {
    Header: "Clicks",
    accessor: "click",
  },
  {
    Header: "Desktop",
    accessor: "desktop",
    width: 100,
  },
  {
    Header: "Tablet",
    accessor: "ipad",
    width: 100,
  },
  {
    Header: "Phone",
    accessor: "phone",
    width: 100,
  },
];
