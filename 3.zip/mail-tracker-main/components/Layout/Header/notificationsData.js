export const notificationsData = [
  {
    id: 1,
    name: "Complete Today Task",
    time: "1 Mins",
  },
  {
    id: 2,
    name: "Director Metting",
    time: "10 Mins",
  },
  {
    id: 3,
    name: "Update Password",
    time: "25 Mins",
  },
  {
    id: 4,
    name: "Complete Today Task",
    time: "45 Mins",
  },
  {
    id: 5,
    name: "Complete Today Task",
    time: "1 Mins",
  },
  {
    id: 6,
    name: "Director Metting",
    time: "10 Mins",
  },
  {
    id: 7,
    name: "Update Password",
    time: "25 Mins",
  },
  {
    id: 8,
    name: "Complete Today Task",
    time: "45 Mins",
  },
  {
    id: 9,
    name: "Complete Today Task",
    time: "45 Mins",
  },
  {
    id: 10,
    name: "Complete Today Task",
    time: "45 Mins",
  },
];
