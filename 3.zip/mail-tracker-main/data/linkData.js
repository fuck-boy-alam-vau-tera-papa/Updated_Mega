export const linkData = [
  {
    website: "https://megapecrsonals.com/176",
    website_name: "Mega.com",
    status: "Pending",
  },
  {
    website: "https://megapecrsonals.com/176",
    website_name: "Mega.com",
    status: "Pending",
  },
  {
    website: "https://megapecrsonals.com/176",
    website_name: "Mega.com",
    status: "Pending",
  },
  {
    website: "https://megapecrsonals.com/176",
    website_name: "Mega.com",
    status: "Pending",
  },
  {
    website: "https://megapecrsonals.com/176",
    website_name: "Mega.com",
    status: "Pending",
  },
  {
    website: "https://megapecrsonals.com/176",
    website_name: "Mega.com",
    status: "Pending",
  },
  {
    website: "https://megapecrsonals.com/176",
    website_name: "Mega.com",
    status: "Pending",
  },
];
