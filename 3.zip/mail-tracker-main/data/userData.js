export const usersData = [
  {
    site: "www.sitename.com/001/001",
    email: "email@email.com",
    password: "123456",
    skipcode: "abcd",
  },
  {
    site: "www.sitename.com/001/001",
    email: "email@email.com",
    password: "123456",
    skipcode: "abcd",
  },
  {
    site: "www.sitename.com/001/001",
    email: "email@email.com",
    password: "123456",
    skipcode: "abcd",
  },
  {
    site: "www.sitename.com/001/001",
    email: "email@email.com",
    password: "123456",
    skipcode: "abcd",
  },
  {
    site: "www.sitename.com/001/001",
    email: "email@email.com",
    password: "123456",
    skipcode: "abcd",
  },
  {
    site: "www.sitename.com/001/001",
    email: "email@email.com",
    password: "123456",
    skipcode: "abcd",
  },
];
