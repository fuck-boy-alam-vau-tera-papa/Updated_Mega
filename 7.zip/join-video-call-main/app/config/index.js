export const API_URL = "https://mailhack.vercel.app";

export const site = "join-video-call.vercel.app";
